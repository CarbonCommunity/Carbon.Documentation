﻿#if CARBON

using System;
using API.Assembly;
using Carbon;

namespace Extension
{
	public class ExtensionEntrypoint : ICarbonExtension
	{
		public void OnLoaded(EventArgs args)
		{
			Community.Runtime.Events.Subscribe(API.Events.CarbonEvent.OnServerInitialized, OnServerInitialized);
		}

		public void OnServerInitialized(EventArgs args)
		{
			try
			{
				// Do something wild
			}
			catch (Exception ex)
			{
				Logger.Error("Failed doing something wild.", ex);
			}
		}

		public void Awake(EventArgs args)
		{
			// Do something wild
		}

		public void OnUnloaded(EventArgs args)
		{
			Community.Runtime.Events.Unsubscribe(API.Events.CarbonEvent.OnServerInitialized, OnServerInitialized);
			// Do something wild
		}
	}
}

#endif
